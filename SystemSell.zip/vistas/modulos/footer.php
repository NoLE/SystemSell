<footer class="main-footer">
	<strong>Copyright &copy; 2019 <a href="http://www.activeweb.cl" target="_blank">ActiveWeb</a>.</strong>
	Todos los Derechos Reservados.
</footer>